
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React, { useState, useEffect, Suspense, memo } from 'react';
import { SurfaceCodeDiagram, TransformerDecoderDiagram, PerformanceMetricDiagram } from './components/Diagrams';
import { ArrowDown, Menu, X, BookOpen, Sun, Moon } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

// Lazy load heavy 3D scenes
const HeroScene = React.lazy(() => import('./components/QuantumScene').then(m => ({ default: m.HeroScene })));
const QuantumComputerScene = React.lazy(() => import('./components/QuantumScene').then(m => ({ default: m.QuantumComputerScene })));

const LoadingSpinner = () => (
  <div className="flex items-center justify-center w-full h-full">
    <div className="w-8 h-8 border-2 border-nobel-gold border-t-transparent rounded-full animate-spin"></div>
  </div>
);

const AuthorCard = memo(({ name, role, delay }: { name: string, role: string, delay: string }) => {
  return (
    <div className="flex flex-col group animate-fade-in-up items-center p-8 bg-white dark:bg-stone-900 rounded-xl border border-stone-200 dark:border-stone-800 shadow-sm hover:shadow-md transition-all duration-300 w-full max-w-xs hover:border-nobel-gold/50" style={{ animationDelay: delay }}>
      <h3 className="font-serif text-2xl text-stone-900 dark:text-stone-100 text-center mb-3">{name}</h3>
      <div className="w-12 h-0.5 bg-nobel-gold mb-4 opacity-60"></div>
      <p className="text-xs text-stone-500 dark:text-stone-400 font-bold uppercase tracking-widest text-center leading-relaxed">{role}</p>
    </div>
  );
});

// Liquid Water Transition Component
const ThemeRipple = ({ isDark }: { isDark: boolean }) => (
  <motion.div
    initial={{ scale: 0, opacity: 0 }}
    animate={{ scale: 4, opacity: 1 }}
    exit={{ opacity: 0 }}
    transition={{ duration: 0.8, ease: "circOut" }}
    className="fixed inset-0 z-[60] pointer-events-none flex items-center justify-center"
  >
    <svg width="100%" height="100%" viewBox="0 0 100 100" preserveAspectRatio="none" className="w-full h-full">
      <defs>
        <filter id="liquid-filter">
          <feTurbulence type="fractalNoise" baseFrequency="0.015" numOctaves="3" result="noise" />
          <feDisplacementMap in="SourceGraphic" in2="noise" scale="15" />
        </filter>
      </defs>
      <circle 
        cx="50" cy="50" r="40" 
        fill={isDark ? "#0F1115" : "#F9F8F4"} 
        filter="url(#liquid-filter)"
      />
    </svg>
  </motion.div>
);

const App: React.FC = () => {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [isAnimatingTheme, setIsAnimatingTheme] = useState(false);
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('theme');
      if (saved) return saved as 'light' | 'dark';
      return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    }
    return 'light';
  });

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setIsAnimatingTheme(true);
    setTimeout(() => {
      setTheme(t => t === 'light' ? 'dark' : 'light');
      setTimeout(() => setIsAnimatingTheme(false), 800);
    }, 100);
  };

  const scrollToSection = (id: string) => (e: React.MouseEvent) => {
    e.preventDefault();
    setMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      // Renamed headerOffset to scrollingOffset to avoid collision with standard tag name
      const scrollingOffset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - scrollingOffset;
      window.scrollTo({ top: offsetPosition, behavior: "smooth" });
    }
  };

  return (
    <div className="min-h-screen bg-nobel-cream dark:bg-nobel-dark text-stone-800 dark:text-stone-200 transition-colors duration-500 selection:bg-nobel-gold selection:text-white overflow-x-hidden">
      
      {/* Water Transition Overlay */}
      <AnimatePresence>
        {isAnimatingTheme && <ThemeRipple isDark={theme === 'light'} />}
      </AnimatePresence>

      {/* Navigation */}
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${scrolled ? 'bg-white/80 dark:bg-nobel-dark/80 backdrop-blur-xl shadow-lg py-3' : 'bg-transparent py-6'}`}>
        <div className="container mx-auto px-6 flex justify-between items-center">
          <div className="flex items-center gap-4 cursor-pointer group" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
            <div className="w-10 h-10 bg-nobel-gold rounded-xl flex items-center justify-center text-white font-serif font-bold text-2xl shadow-lg transition-transform group-hover:scale-110 pb-1">α</div>
            <span className={`font-serif font-bold text-xl tracking-wider transition-all ${scrolled ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-4 md:opacity-100 md:translate-x-0 dark:text-white'}`}>
              ALPHAQUBIT
            </span>
          </div>
          
          <div className="hidden md:flex items-center gap-8 text-xs font-bold tracking-[0.2em] text-stone-600 dark:text-stone-400">
            <a href="#introduction" onClick={scrollToSection('introduction')} className="hover:text-nobel-gold transition-colors cursor-pointer uppercase">Introduction</a>
            <a href="#science" onClick={scrollToSection('science')} className="hover:text-nobel-gold transition-colors cursor-pointer uppercase">Science</a>
            <a href="#impact" onClick={scrollToSection('impact')} className="hover:text-nobel-gold transition-colors cursor-pointer uppercase">Impact</a>
            
            <div className="w-[1px] h-6 bg-stone-200 dark:bg-stone-800 mx-2"></div>

            <button 
              onClick={toggleTheme}
              className="p-2.5 rounded-xl bg-stone-100 dark:bg-stone-900 hover:bg-stone-200 dark:hover:bg-stone-800 transition-all text-stone-900 dark:text-stone-100 shadow-sm active:scale-95"
              aria-label="Toggle Theme"
            >
              {theme === 'light' ? <Moon size(18) /> : <Sun size(18) />}
            </button>

            <a 
              href="https://doi.org/10.1038/s41586-024-08148-8" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="px-6 py-2.5 bg-stone-900 dark:bg-white dark:text-stone-900 text-white rounded-xl hover:bg-stone-800 dark:hover:bg-stone-100 transition-all shadow-md hover:shadow-xl active:scale-95 cursor-pointer"
            >
              READ PAPER
            </a>
          </div>

          <div className="md:hidden flex items-center gap-4">
            <button onClick={toggleTheme} className="p-2 rounded-lg bg-stone-100 dark:bg-stone-900 text-stone-900 dark:text-stone-100">
               {theme === 'light' ? <Moon size={20} /> : <Sun size={20} />}
            </button>
            <button className="p-2 rounded-lg bg-stone-900 dark:bg-white text-white dark:text-stone-900" onClick={() => setMenuOpen(!menuOpen)}>
              {menuOpen ? <X size={20}/> : <Menu size={20}/>}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu */}
      <AnimatePresence>
        {menuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed inset-0 z-40 bg-white dark:bg-nobel-dark flex flex-col items-center justify-center gap-8 text-2xl font-serif"
          >
              <a href="#introduction" onClick={scrollToSection('introduction')} className="hover:text-nobel-gold transition-colors dark:text-white">Introduction</a>
              <a href="#science" onClick={scrollToSection('science')} className="hover:text-nobel-gold transition-colors dark:text-white">Science</a>
              <a href="#impact" onClick={scrollToSection('impact')} className="hover:text-nobel-gold transition-colors dark:text-white">Impact</a>
              <a 
                href="https://doi.org/10.1038/s41586-024-08148-8" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="px-8 py-3 bg-stone-900 dark:bg-white dark:text-stone-900 text-white rounded-xl shadow-lg"
              >
                View Paper
              </a>
              <button onClick={() => setMenuOpen(false)} className="mt-8 p-4 rounded-full border border-stone-200 dark:border-stone-800 text-stone-400"><X size={32} /></button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Hero Section */}
      <header className="relative h-screen flex items-center justify-center overflow-hidden">
        <Suspense fallback={<div className="absolute inset-0 bg-nobel-cream dark:bg-nobel-dark transition-colors duration-500" />}>
          <HeroScene />
        </Suspense>
        
        <div className="absolute inset-0 z-0 pointer-events-none bg-[radial-gradient(circle_at_center,rgba(249,248,244,0.7)_0%,rgba(249,248,244,0.2)_60%,rgba(249,248,244,0)_100%)] dark:bg-[radial-gradient(circle_at_center,rgba(15,17,21,0.6)_0%,rgba(15,17,21,0.2)_60%,rgba(15,17,21,0)_100%)]" />

        <div className="relative z-10 container mx-auto px-6 text-center">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="inline-block mb-6 px-4 py-1.5 border-2 border-nobel-gold text-nobel-gold text-xs tracking-[0.3em] uppercase font-black rounded-full backdrop-blur-md bg-white/40 dark:bg-black/40"
          >
            NATURE • NOVEMBER 2024
          </motion.div>
          
          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="font-serif text-6xl md:text-8xl lg:text-9xl font-bold leading-none mb-8 text-stone-900 dark:text-white tracking-tight"
          >
            AlphaQubit
            <span className="italic font-light text-stone-500 dark:text-stone-400 text-2xl md:text-4xl lg:text-5xl block mt-6 tracking-normal">Decoding the Quantum Future</span>
          </motion.h1>
          
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6 }}
            className="max-w-3xl mx-auto text-xl md:text-2xl text-stone-700 dark:text-stone-300 font-light leading-relaxed mb-16"
          >
            The world's first AI-driven error correction model that outperforms traditional algorithms on physical quantum processors.
          </motion.p>
          
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8 }}
            className="flex justify-center"
          >
             <a href="#introduction" onClick={scrollToSection('introduction')} className="group flex flex-col items-center gap-3 text-xs font-black tracking-[0.4em] text-stone-400 hover:text-nobel-gold transition-colors cursor-pointer">
                <span>EXPLORE</span>
                <span className="p-3 border-2 border-stone-200 dark:border-stone-800 rounded-2xl group-hover:border-nobel-gold transition-all bg-white/40 dark:bg-white/5 backdrop-blur-sm group-hover:-translate-y-1">
                    <ArrowDown size={20} className="animate-bounce" />
                </span>
             </a>
          </motion.div>
        </div>
      </header>

      <main>
        <section id="introduction" className="py-32 bg-white dark:bg-[#121418] transition-colors duration-500">
          <div className="container mx-auto px-6 md:px-12 grid grid-cols-1 md:grid-cols-12 gap-16 items-start">
            <div className="md:col-span-5">
              <div className="inline-block mb-4 text-xs font-black tracking-[0.2em] text-nobel-gold uppercase">THE CHALLENGE</div>
              <h2 className="font-serif text-5xl lg:text-6xl mb-8 leading-tight text-stone-900 dark:text-white">Conquering Quantum Noise</h2>
              <div className="w-24 h-1.5 bg-nobel-gold rounded-full mb-8"></div>
              <p className="text-stone-500 dark:text-stone-400 italic font-serif text-xl">
                "The primary barrier to practical quantum computing is error rate. AlphaQubit bridges the gap between theory and hardware."
              </p>
            </div>
            <div className="md:col-span-7 text-xl text-stone-600 dark:text-stone-400 leading-relaxed space-y-8 font-light">
              <p>
                <span className="text-7xl float-left mr-4 mt-[-4px] font-serif text-nobel-gold font-bold">Q</span>uantum processors are incredibly delicate. Even cosmic rays or slight temperature changes can flip a qubit's state. To protect information, scientists use the <strong>Surface Code</strong>, spreading one "logical" qubit across many physical ones.
              </p>
              <p>
                The difficulty lies in <strong className="text-stone-900 dark:text-stone-200 font-medium">Decoding</strong>: translating the complex, noisy error signals into correctable actions in real-time. This is where AlphaQubit excels.
              </p>
              <div className="p-8 bg-stone-50 dark:bg-stone-900/40 rounded-3xl border border-stone-100 dark:border-stone-800">
                <p className="text-stone-900 dark:text-stone-100 font-medium mb-2">AlphaQubit's Core Achievement:</p>
                <p className="text-lg">Trained on millions of simulated and real Sycamore hardware samples, it achieves <strong>higher accuracy</strong> than the current gold standard (MWPM) across all tested distances.</p>
              </div>
            </div>
          </div>
        </section>

        <section id="science" className="py-32 bg-stone-50 dark:bg-nobel-dark transition-colors duration-500">
            <div className="container mx-auto px-6">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
                    <div>
                        <div className="inline-flex items-center gap-3 px-4 py-2 bg-white dark:bg-stone-800 text-nobel-gold text-xs font-black tracking-widest uppercase rounded-2xl mb-8 border border-stone-100 dark:border-stone-700 shadow-sm">
                            <BookOpen size={16}/> THE ARCHITECTURE
                        </div>
                        <h2 className="font-serif text-5xl md:text-6xl mb-8 text-stone-900 dark:text-white">Spatial & Temporal Decoding</h2>
                        <p className="text-xl text-stone-600 dark:text-stone-400 mb-8 leading-relaxed font-light">
                           AlphaQubit doesn't just look at a snapshot of errors. It uses a transformer decoder to process sequences of syndrome measurements, understanding how errors evolve over time.
                        </p>
                        <ul className="space-y-4 text-stone-700 dark:text-stone-300">
                            <li className="flex gap-4 items-start">
                                <span className="w-6 h-6 rounded-full bg-nobel-gold/20 flex items-center justify-center text-nobel-gold shrink-0 mt-1">•</span>
                                <span><strong>Surface Code Synergy:</strong> Optimized for d=3 to d=11 grids.</span>
                            </li>
                            <li className="flex gap-4 items-start">
                                <span className="w-6 h-6 rounded-full bg-nobel-gold/20 flex items-center justify-center text-nobel-gold shrink-0 mt-1">•</span>
                                <span><strong>Noise Adaptation:</strong> Learns specific hardware biases.</span>
                            </li>
                        </ul>
                    </div>
                    <div className="relative">
                        <div className="absolute -inset-4 bg-nobel-gold/5 blur-3xl rounded-full"></div>
                        <SurfaceCodeDiagram />
                    </div>
                </div>
            </div>
        </section>

        <section className="py-32 bg-stone-900 dark:bg-black text-white overflow-hidden relative">
            <div className="container mx-auto px-6 relative z-10">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-24 items-center">
                     <div className="order-2 lg:order-1 scale-110">
                        <TransformerDecoderDiagram />
                     </div>
                     <div className="order-1 lg:order-2">
                        <div className="inline-flex items-center gap-3 px-4 py-2 bg-stone-800 text-nobel-gold text-xs font-black tracking-widest uppercase rounded-2xl mb-8 border border-stone-700 shadow-xl">
                            ML INNOVATION
                        </div>
                        <h2 className="font-serif text-5xl md:text-6xl mb-8 leading-tight">Neural Error <br/>Correction</h2>
                        <p className="text-xl text-stone-400 leading-relaxed font-light mb-8">
                            By treating decoding as a translation task—mapping syndromes to corrections—AlphaQubit achieves a paradigm shift in fault-tolerant computing.
                        </p>
                        <div className="grid grid-cols-2 gap-8">
                            <div className="border-l-2 border-nobel-gold pl-6">
                                <div className="text-3xl font-serif mb-1">99.9%</div>
                                <div className="text-xs text-stone-500 uppercase font-bold tracking-widest">Accuracy Floor</div>
                            </div>
                            <div className="border-l-2 border-nobel-gold pl-6">
                                <div className="text-3xl font-serif mb-1">6x</div>
                                <div className="text-xs text-stone-500 uppercase font-bold tracking-widest">Efficiency Gain</div>
                            </div>
                        </div>
                     </div>
                </div>
            </div>
        </section>

        <section className="py-32 bg-white dark:bg-nobel-dark">
            <div className="container mx-auto px-6">
                <div className="max-w-4xl mx-auto text-center mb-20">
                    <h2 className="font-serif text-5xl md:text-6xl mb-8 text-stone-900 dark:text-white">Empirical Superiority</h2>
                    <p className="text-xl text-stone-600 dark:text-stone-400 font-light">
                        Measured performance on the Sycamore processor confirms that AlphaQubit reduces the logical error rate more effectively as the code distance increases.
                    </p>
                </div>
                <div className="max-w-4xl mx-auto">
                    <PerformanceMetricDiagram />
                </div>
            </div>
        </section>

        <section id="impact" className="py-32 bg-stone-50 dark:bg-[#121418] border-y border-stone-200 dark:border-stone-800">
             <div className="container mx-auto px-6 grid grid-cols-1 md:grid-cols-12 gap-20">
                <div className="md:col-span-6 relative">
                    <div className="aspect-[4/3] bg-white dark:bg-stone-900 rounded-[2rem] overflow-hidden relative border border-stone-200 dark:border-stone-800 shadow-2xl">
                        <Suspense fallback={<LoadingSpinner />}>
                          <QuantumComputerScene />
                        </Suspense>
                        <div className="absolute top-6 right-6 px-4 py-2 bg-stone-900/80 backdrop-blur-md rounded-full text-[10px] font-bold text-white uppercase tracking-widest">
                            Live Simulation
                        </div>
                    </div>
                </div>
                <div className="md:col-span-6 flex flex-col justify-center">
                    <div className="inline-block mb-4 text-xs font-black tracking-[0.2em] text-stone-500 uppercase">FUTURE PROSPECT</div>
                    <h2 className="font-serif text-5xl mb-8 text-stone-900 dark:text-white">The Road to Scale</h2>
                    <p className="text-xl text-stone-600 dark:text-stone-400 mb-10 leading-relaxed font-light">
                        AlphaQubit is not just a research project; it's a blueprint for the "OS" of future quantum computers, where AI manages the hardware layer.
                    </p>
                    <div className="p-10 bg-white dark:bg-stone-900 rounded-3xl border border-stone-200 dark:border-stone-800 shadow-xl relative overflow-hidden group">
                        <div className="absolute top-0 right-0 w-32 h-32 bg-nobel-gold/5 rounded-full -mr-16 -mt-16 transition-transform group-hover:scale-150"></div>
                        <p className="font-serif italic text-2xl text-stone-800 dark:text-stone-200 mb-6 leading-snug">
                            "A major milestone in demonstrating that machine learning will be fundamental to quantum scalability."
                        </p>
                        <div className="flex items-center gap-4">
                            <div className="w-12 h-12 bg-nobel-gold rounded-xl flex items-center justify-center text-white font-bold">G</div>
                            <div>
                                <span className="text-sm font-black text-stone-900 dark:text-white tracking-wider block uppercase">GOOGLE DEEPMIND</span>
                                <span className="text-xs text-stone-400 uppercase tracking-widest">Research Division, 2024</span>
                            </div>
                        </div>
                    </div>
                </div>
             </div>
        </section>

        <section id="authors" className="py-32 bg-white dark:bg-nobel-dark">
           <div className="container mx-auto px-6">
                <div className="text-center mb-20">
                    <h2 className="font-serif text-5xl mb-6 text-stone-900 dark:text-white">Authors & Credits</h2>
                    <p className="text-stone-500 dark:text-stone-400 text-lg">A collaborative effort between Google DeepMind and Quantum AI.</p>
                </div>
                <div className="flex flex-col md:flex-row gap-10 justify-center items-stretch flex-wrap">
                    <AuthorCard name="Johannes Bausch" role="Research Scientist, DeepMind" delay="0s" />
                    <AuthorCard name="Andrew W. Senior" role="Principal Scientist, DeepMind" delay="0.1s" />
                    <AuthorCard name="Michael Newman" role="Quantum AI Lead" delay="0.2s" />
                </div>
           </div>
        </section>
      </main>

      <footer className="bg-stone-900 dark:bg-black text-stone-500 py-24 border-t border-stone-800">
        <div className="container mx-auto px-6 grid grid-cols-1 md:grid-cols-3 gap-16">
            <div className="md:col-span-2">
                <div className="text-white font-serif font-bold text-3xl mb-6">AlphaQubit</div>
                <p className="text-lg max-w-md mb-8 font-light">Providing the high-accuracy decoding necessary for the next generation of fault-tolerant quantum computers.</p>
                <div className="flex gap-6">
                    <a href="#" className="hover:text-nobel-gold transition-colors font-bold text-xs uppercase tracking-widest">Documentation</a>
                    <a href="#" className="hover:text-nobel-gold transition-colors font-bold text-xs uppercase tracking-widest">Source Code</a>
                    <a href="#" className="hover:text-nobel-gold transition-colors font-bold text-xs uppercase tracking-widest">API Access</a>
                </div>
            </div>
            <div className="flex flex-col justify-end text-xs font-mono space-y-2">
                <div className="text-stone-400">CITATIONS:</div>
                <p>Bausch, J., Newman, M. et al. Nature 635, 831–837 (2024).</p>
                <p className="text-stone-700">Visual Research Narrative developed for 2024 Documentation.</p>
            </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
