
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React, { useRef, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Float, MeshDistortMaterial, Sphere, Torus, Cylinder, Stars, Environment, Box } from '@react-three/drei';
import * as THREE from 'three';

const QuantumParticle = ({ position, color, scale = 1 }: { position: [number, number, number]; color: string; scale?: number }) => {
  const ref = useRef<THREE.Mesh>(null);
  
  useFrame((state) => {
    if (ref.current) {
      const t = state.clock.getElapsedTime();
      ref.current.position.y = position[1] + Math.sin(t * 1.5 + position[0]) * 0.15;
      ref.current.rotation.x = t * 0.4;
      ref.current.rotation.z = t * 0.25;
    }
  });

  return (
    <Sphere ref={ref} args={[1, 16, 16]} position={position} scale={scale}>
      <MeshDistortMaterial
        color={color}
        envMapIntensity={0.8}
        clearcoat={0.5}
        metalness={0.6}
        distort={0.3}
        speed={1.5}
      />
    </Sphere>
  );
};

const MacroscopicWave = () => {
  const ref = useRef<THREE.Mesh>(null);
  
  useFrame((state) => {
    if (ref.current) {
       const t = state.clock.getElapsedTime();
       ref.current.rotation.x = Math.sin(t * 0.1) * 0.15;
       ref.current.rotation.y = t * 0.08;
    }
  });

  return (
    <Torus ref={ref} args={[3, 0.05, 12, 64]} rotation={[Math.PI / 2, 0, 0]}>
      <meshStandardMaterial color="#C5A059" emissive="#C5A059" emissiveIntensity={0.3} transparent opacity={0.4} wireframe />
    </Torus>
  );
}

export const HeroScene: React.FC = () => {
  const isDark = document.documentElement.classList.contains('dark');
  
  return (
    <div className="absolute inset-0 z-0 opacity-80 pointer-events-none">
      <Canvas camera={{ position: [0, 0, 7], fov: 40 }} gl={{ antialias: true }}>
        <ambientLight intensity={isDark ? 0.2 : 0.6} />
        <pointLight position={[10, 10, 10]} intensity={isDark ? 1.5 : 1} color={isDark ? "#C5A059" : "#fff"} />
        <Float speed={1.2} rotationIntensity={0.15} floatIntensity={0.4}>
          <QuantumParticle position={[0, 0, 0]} color={isDark ? "#6366f1" : "#4F46E5"} scale={1.4} />
          <MacroscopicWave />
        </Float>
        
        <Float speed={1.8} rotationIntensity={0.4} floatIntensity={0.8}>
           <QuantumParticle position={[-4, 1.5, -3]} color={isDark ? "#a855f7" : "#9333EA"} scale={0.6} />
           <QuantumParticle position={[4, -1.5, -4]} color="#C5A059" scale={0.7} />
        </Float>

        <Environment preset={isDark ? "night" : "city"} />
        <Stars radius={100} depth={50} count={isDark ? 2000 : 800} factor={4} saturation={0} fade speed={0.5} />
      </Canvas>
    </div>
  );
};

export const QuantumComputerScene: React.FC = () => {
  const isDark = document.documentElement.classList.contains('dark');

  return (
    <div className="w-full h-full absolute inset-0">
      <Canvas camera={{ position: [0, 0, 5], fov: 45 }} gl={{ powerPreference: "high-performance" }}>
        <ambientLight intensity={isDark ? 0.3 : 1} />
        <spotLight position={[5, 5, 5]} angle={0.25} penumbra={1} intensity={isDark ? 3 : 2} color="#C5A059" />
        <pointLight position={[-5, -5, -5]} intensity={0.4} />
        <Environment preset={isDark ? "night" : "studio"} />
        
        <Float rotationIntensity={0.3} floatIntensity={0.15} speed={0.8}>
          <group position={[0, 0.4, 0]}>
            {/* Top Plate */}
            <Cylinder args={[1.2, 1.2, 0.08, 32]} position={[0, 1, 0]}>
              <meshStandardMaterial color={isDark ? "#8a6d3b" : "#C5A059"} metalness={1} roughness={0.1} />
            </Cylinder>
            
            {/* Middle Stage */}
            <Cylinder args={[1, 1, 0.08, 32]} position={[0, 0.2, 0]}>
              <meshStandardMaterial color={isDark ? "#8a6d3b" : "#C5A059"} metalness={1} roughness={0.1} />
            </Cylinder>
            
            {/* Bottom Stage */}
            <Cylinder args={[0.6, 0.6, 0.08, 32]} position={[0, -0.6, 0]}>
              <meshStandardMaterial color={isDark ? "#8a6d3b" : "#C5A059"} metalness={1} roughness={0.1} />
            </Cylinder>

            {/* Rods */}
            {[0.5, -0.5].map((x, i) => (
               <Cylinder key={`rod-${i}`} args={[0.03, 0.03, 0.8, 8]} position={[x, 0.6, 0]}>
                 <meshStandardMaterial color={isDark ? "#444" : "#D1D5DB"} metalness={0.9} roughness={0.1} />
               </Cylinder>
            ))}

            {/* Copper Coils */}
            <Torus args={[0.7, 0.012, 12, 48]} position={[0, -0.2, 0]} rotation={[Math.PI/2, 0, 0]}>
               <meshStandardMaterial color="#B87333" metalness={0.9} roughness={0.2} />
            </Torus>
            
            {/* Processor */}
            <Box args={[0.25, 0.04, 0.25]} position={[0, -0.7, 0]}>
                <meshStandardMaterial color={isDark ? "#000" : "#111"} metalness={0.8} roughness={0.2} emissive={isDark ? "#C5A059" : "#000"} emissiveIntensity={isDark ? 0.2 : 0} />
            </Box>
          </group>
        </Float>
      </Canvas>
    </div>
  );
}
