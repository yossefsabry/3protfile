
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React, { useState, useEffect, memo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Activity, Cpu, BarChart2 } from 'lucide-react';

// --- SURFACE CODE DIAGRAM ---
export const SurfaceCodeDiagram = memo(() => {
  const [errors, setErrors] = useState<number[]>([]);
  
  const adjacency: Record<number, number[]> = {
    0: [0, 1],
    1: [0, 2],
    2: [1, 3],
    3: [2, 3],
    4: [0, 1, 2, 3],
  };

  const toggleError = (id: number) => {
    setErrors(prev => prev.includes(id) ? prev.filter(e => e !== id) : [...prev, id]);
  };

  const activeStabilizers = [0, 1, 2, 3].filter(stabId => {
    let errorCount = 0;
    Object.entries(adjacency).forEach(([dataId, stabs]) => {
        if (errors.includes(parseInt(dataId)) && stabs.includes(stabId)) {
            errorCount++;
        }
    });
    return errorCount % 2 !== 0;
  });

  return (
    <div className="flex flex-col items-center p-8 bg-white dark:bg-stone-900 rounded-xl shadow-sm border border-stone-200 dark:border-stone-800 transition-colors my-8">
      <h3 className="font-serif text-xl mb-4 text-stone-800 dark:text-stone-200">Interactive: Surface Code Detection</h3>
      <div className="relative w-64 h-64 bg-[#F5F4F0] dark:bg-black rounded-lg border border-stone-200 dark:border-stone-800 p-4 flex flex-wrap justify-between content-between">
         <div className="absolute inset-0 pointer-events-none flex items-center justify-center opacity-10 dark:opacity-20">
            <div className="w-2/3 h-2/3 border border-stone-400 dark:border-stone-600"></div>
            <div className="absolute w-full h-[1px] bg-stone-400 dark:bg-stone-600"></div>
            <div className="absolute h-full w-[1px] bg-stone-400 dark:bg-stone-600"></div>
         </div>

         {[
             {id: 0, x: '50%', y: '20%', type: 'Z', color: 'bg-blue-500'},
             {id: 1, x: '20%', y: '50%', type: 'X', color: 'bg-red-500'},
             {id: 2, x: '80%', y: '50%', type: 'X', color: 'bg-red-500'},
             {id: 3, x: '50%', y: '80%', type: 'Z', color: 'bg-blue-500'},
         ].map(stab => (
             <motion.div
                key={`stab-${stab.id}`}
                className={`absolute w-10 h-10 -ml-5 -mt-5 flex items-center justify-center text-white text-xs font-bold rounded-sm shadow-sm transition-all duration-300 ${activeStabilizers.includes(stab.id) ? stab.color + ' opacity-100 scale-110 ring-4 ring-offset-2 dark:ring-stone-800' : 'bg-stone-300 dark:bg-stone-700 opacity-40'}`}
                style={{ left: stab.x, top: stab.y }}
             >
                 {stab.type}
             </motion.div>
         ))}

         {[
             {id: 0, x: '20%', y: '20%'}, {id: 1, x: '80%', y: '20%'},
             {id: 4, x: '50%', y: '50%'},
             {id: 2, x: '20%', y: '80%'}, {id: 3, x: '80%', y: '80%'},
         ].map(q => (
             <button
                key={`data-${q.id}`}
                onClick={() => toggleError(q.id)}
                className={`absolute w-8 h-8 -ml-4 -mt-4 rounded-full border-2 flex items-center justify-center transition-all duration-200 z-10 ${errors.includes(q.id) ? 'bg-stone-800 dark:bg-nobel-gold border-stone-900 dark:border-nobel-gold text-nobel-gold dark:text-stone-900' : 'bg-white dark:bg-stone-800 border-stone-300 dark:border-stone-700 hover:border-stone-500'}`}
                style={{ left: q.x, top: q.y }}
             >
                {errors.includes(q.id) && <Activity size={14} />}
             </button>
         ))}
      </div>
      <div className="mt-4 text-sm font-serif italic text-stone-600 dark:text-stone-400">
        {errors.length === 0 ? "System is stable." : `Detected ${activeStabilizers.length} parity violations.`}
      </div>
    </div>
  );
});

// --- TRANSFORMER DECODER DIAGRAM ---
export const TransformerDecoderDiagram = memo(() => {
  const [step, setStep] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => setStep(s => (s + 1) % 4), 2500);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex flex-col items-center p-8 bg-[#F5F4F0] dark:bg-stone-900 rounded-xl border border-stone-200 dark:border-stone-800 my-8 transition-colors">
      <h3 className="font-serif text-xl mb-4 text-stone-900 dark:text-stone-100">AlphaQubit Architecture</h3>
      <div className="relative w-full max-w-lg h-52 bg-white dark:bg-black rounded-lg shadow-inner overflow-hidden mb-6 border border-stone-200 dark:border-stone-800 flex items-center justify-center gap-8 p-4">
        <div className="flex flex-col items-center gap-2">
            <div className={`w-14 h-14 rounded-lg border-2 flex items-center justify-center transition-colors duration-500 ${step === 0 ? 'border-nobel-gold bg-nobel-gold/10' : 'border-stone-200 dark:border-stone-800'}`}>
                <div className="grid grid-cols-3 gap-1 scale-75">
                    {[...Array(9)].map((_, i) => <div key={i} className={`w-2 h-2 rounded-full ${Math.random() > 0.6 ? 'bg-stone-800 dark:bg-stone-400' : 'bg-stone-200 dark:bg-stone-800'}`}></div>)}
                </div>
            </div>
            <span className="text-[9px] uppercase font-bold tracking-wider text-stone-500">Syndrome</span>
        </div>
        <motion.div animate={{ opacity: step >= 1 ? 1 : 0.2 }} className="dark:text-stone-600">→</motion.div>
        <div className="flex flex-col items-center gap-2">
             <div className={`w-20 h-20 rounded-xl border-2 flex items-center justify-center transition-colors duration-500 relative overflow-hidden ${step === 1 || step === 2 ? 'border-stone-800 dark:border-nobel-gold bg-stone-900 text-white' : 'border-stone-200 dark:border-stone-800'}`}>
                <Cpu size={24} className={step === 1 || step === 2 ? 'text-nobel-gold animate-pulse' : 'text-stone-300 dark:text-stone-700'} />
             </div>
             <span className="text-[9px] uppercase font-bold tracking-wider text-stone-500">ML Decoder</span>
        </div>
        <motion.div animate={{ opacity: step >= 3 ? 1 : 0.2 }} className="dark:text-stone-600">→</motion.div>
        <div className="flex flex-col items-center gap-2">
            <div className={`w-14 h-14 rounded-lg border-2 flex items-center justify-center transition-colors duration-500 ${step === 3 ? 'border-green-500 bg-green-50 dark:bg-green-900/20' : 'border-stone-200 dark:border-stone-800'}`}>
                {step === 3 ? <span className="text-xl font-serif text-green-600">Done</span> : <span className="text-xl font-serif text-stone-300 dark:text-stone-800">?</span>}
            </div>
            <span className="text-[9px] uppercase font-bold tracking-wider text-stone-500">Correction</span>
        </div>
      </div>
    </div>
  );
});

// --- PERFORMANCE CHART ---
export const PerformanceMetricDiagram = memo(() => {
    const [distance, setDistance] = useState<3 | 5 | 11>(5);
    const data = {
        3: { mwpm: 3.5, alpha: 2.9 },
        5: { mwpm: 3.6, alpha: 2.75 },
        11: { mwpm: 0.0041, alpha: 0.0009 } 
    };
    const currentData = data[distance];
    const maxVal = Math.max(currentData.mwpm, currentData.alpha) * 1.3;
    const formatValue = (val: number) => val < 0.01 ? val.toFixed(4) + '%' : val.toFixed(2) + '%';

    return (
        <div className="flex flex-col md:flex-row gap-8 items-center p-8 bg-stone-900 dark:bg-black text-stone-100 rounded-xl my-8 border border-stone-800 shadow-lg transition-colors">
            <div className="flex-1 min-w-[240px]">
                <h3 className="font-serif text-xl mb-2 text-nobel-gold">Performance vs Standard</h3>
                <p className="text-stone-400 text-sm mb-4 leading-relaxed">Lower Logical Error Rate (LER) indicates better stability.</p>
                <div className="flex gap-2 mt-6">
                    {[3, 5, 11].map((d) => (
                        <button key={d} onClick={() => setDistance(d as any)} className={`px-3 py-1.5 rounded text-xs font-medium transition-all duration-200 border ${distance === d ? 'bg-nobel-gold text-stone-900 border-nobel-gold' : 'bg-transparent text-stone-400 border-stone-700 hover:border-stone-500'}`}>Dist {d}</button>
                    ))}
                </div>
            </div>
            <div className="relative w-60 h-64 bg-stone-800/50 dark:bg-stone-900/30 rounded-xl border border-stone-700/50 p-6 flex justify-around items-end">
                <div className="w-16 flex flex-col justify-end items-center h-full z-10">
                    <motion.div className="w-full bg-stone-600 rounded-t-sm" initial={{ height: 0 }} animate={{ height: `${(currentData.mwpm / maxVal) * 100}%` }} transition={{ type: "spring", damping: 20 }} />
                    <div className="h-4 mt-2 text-[8px] font-bold text-stone-500 uppercase">Standard</div>
                </div>
                <div className="w-16 flex flex-col justify-end items-center h-full z-10">
                    <motion.div className="w-full bg-nobel-gold rounded-t-sm shadow-[0_0_15px_rgba(197,160,89,0.3)]" initial={{ height: 0 }} animate={{ height: `${(currentData.alpha / maxVal) * 100}%` }} transition={{ type: "spring", damping: 20 }} />
                    <div className="h-4 mt-2 text-[8px] font-bold text-nobel-gold uppercase">AlphaQubit</div>
                </div>
                <div className="absolute top-4 left-0 right-0 text-center text-[10px] font-mono text-stone-500">Logical Error Rate</div>
            </div>
        </div>
    )
});
